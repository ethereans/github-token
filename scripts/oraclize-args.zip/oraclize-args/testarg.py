import os

s = os.environ['ARGV'] + ": "
for x in range(0,int(os.environ['ARGV'])):
    s += os.environ['ARG'+`x`] + ", "
    
print s;